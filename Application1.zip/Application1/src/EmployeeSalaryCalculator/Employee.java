package EmployeeSalaryCalculator;

public class Employee {
	
	private String name;
	private int ID;
	private double Salary;
	private double bonus;
	
	Employee(){
		name= "Dhanashri";
		ID= 1234;
		Salary= 90000;
		bonus= 80000;
	
	}
	
	void DisplayData() {
		System.out.println("Employee Name: "+name+" ID: "+ID+" Salary: "+Salary+" bonus: "+bonus);
		
	}
	public double calculateTotalSalary() {
        double totalSalary = Salary;
        if (bonus > 0) {
            totalSalary += bonus;
        }

        return totalSalary;
    }
	

}
