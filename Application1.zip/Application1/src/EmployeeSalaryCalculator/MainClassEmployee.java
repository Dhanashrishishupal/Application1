package EmployeeSalaryCalculator;

public class MainClassEmployee {
	public static void main(String[] args) {
		Employee em= new Employee();
		em.DisplayData();
		System.out.println("Total salary: "+em.calculateTotalSalary());
	}

}
