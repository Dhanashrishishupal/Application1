package BankAccountManagementSystem;

public class MainBankAccount {
	public static void main(String[] args) {
		
		BankAccount account= new BankAccount(1234567,80000);
		System.out.println("deposited money: "+account.getBalance());
		account.deposit(80000);
		
		System.out.println("withDraw money: "+account.getBalance());
		account.withdraw(20000);
		account.displayBalance();
	}

}
