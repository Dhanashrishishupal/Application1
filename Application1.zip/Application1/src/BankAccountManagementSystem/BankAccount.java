package BankAccountManagementSystem;

public class BankAccount {
	
	private int  AccountNumber;
	private double balance;
	
	public BankAccount(int  AccountNumber,double CurrentBalance){
		System.out.println("account number: "+AccountNumber+"current balance: "+CurrentBalance);
	
	if (CurrentBalance >= 0) {
        this.balance = CurrentBalance;
    } else {
        this.balance = 0;
        System.out.println("Invalid initial balance. Setting balance to $0.");
    }
}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		if(amount>0) {
			amount= amount+balance;
			System.out.println("Balance after Deposit: "+amount);
		}
	
	}
	public void withdraw(double amount) {
		if(amount>0 && amount<=balance) {
			amount= balance-amount;
			System.out.println("Balance after withdraw money: "+amount);
		} else {
            System.out.println("Invalid withdrawal amount.");
        }
	}
	 public void displayBalance() {
		
	       System.out.println("Remaining Balance: "+ balance);
	    }

	
	

}
