package GradeManagementSystem;

public class Student {
	
	private String name;
	private int RollNo;
	private int marks;
	
	
	Student(String name,int RollNo,int marks){
		this.name=name;
		this.RollNo=RollNo;
		this.marks= marks;
	}
	void DisplayData() {
		System.out.println("name: "+name+" rollNo: "+RollNo+" marks: "+marks);
	}
	
	void CalculateGrade(int marks) {
		if(marks>90) {
			System.out.println("Grade A");
		}else if(marks>80) {
			System.out.println("Grade B");
		}else if(marks>70) {
			System.out.println("Grade c");
		}
		else if(marks>50) {
			System.out.println("Grade D");
		}else {
			System.out.println("fail");
		}
	}
	
	
	

}
