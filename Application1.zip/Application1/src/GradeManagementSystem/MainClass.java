package GradeManagementSystem;

public class MainClass {
	public static void main(String[] args) {
		
		Student st= new Student("dhanashri",123,96);
		st.DisplayData();
	    st.CalculateGrade(89);
	}

}
