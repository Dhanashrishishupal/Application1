package CarMileageManagement;

public class Car {

	String Model;
	int FuelCapacity;
	int mileage;

	Car(String Model, int FuelCapacity, int mileage) {

		if (FuelCapacity <= 0 || mileage <= 0) {
			System.out.println("Fuel capacity and mileage must be greater than zero.");
		} 

		this.Model = Model;
		this.FuelCapacity = FuelCapacity;
		this.mileage = mileage;
	}

	 void DisplayData() {
		System.out.println("car model: " + Model + " FuelCapacity: "+ FuelCapacity+"(in litre)" + " mileage" + mileage+"in (km)");
	}
	 public double CalculateDistance() {
	        return FuelCapacity * mileage;
	    }
	 
	 
	}

