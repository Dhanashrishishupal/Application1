package CarMileageManagement;

public class MainClassCar {
	public static void main(String[] args) {
		
		Car c1= new Car("TATA MOTORS", 120, 60);
		c1.DisplayData();
		
		System.out.println("Distance Travelled: "+c1.CalculateDistance());
		
		
	}

}
